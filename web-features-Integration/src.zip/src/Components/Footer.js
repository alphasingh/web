import React from 'react';


function Footer()
{
    return(
          <section className="bg-dark">
             <div className="container">
               <div className="row">  
                <div className="col-sm-12">
                  <h6 className="text-white text-center mb-3 mt-3">Copyright @ Tiffin Umbrella all Rights Reserved</h6>
                  </div>  
               </div>
             </div>    
          </section>
    
    )
}

export default Footer;